#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

void loading() {
    printf("\n\n\n\n\n");
    printf("\t\t\t\t\t\tPlease Wait...\n");
    fflush(stdout);
    usleep(1000000);
    for (int i = 10; i <= 100; i += 10) {
        printf("\t\t\t\t\t\tLoading %d%%\r", i);
        fflush(stdout);
        usleep(200000);
    }
    system("clear || cls");
}

void text() {
    printf("\n\n\n\n\n");
    printf("\t\t\t\t||Welcome to the Library Management System!||\n\n");
    usleep(100000);
    printf("\t\t\t\t===========================================\n\n\n");
    printf("\t\t\t ||We're here to help you manage your library efficiently.||\n\n");
    printf("\t\t\t\t\t||Please login to get started.||\n\n\n");
}

void userPanel();
void bookPanel();
void addUser();
void searchUser(int);
void deleteUser();
void userList();
void menu();
void endScreen();
void addBook();
void listBook();
void rentBook();
void searchBook(int);
void deleteBook();

int main() {
    text();
    loading();
    menu();
    return 0;
}

void menu() {
    system("clear || cls");
    printf("----------------------------------\n");
    printf(">>> Library Management System <<< \n");
    printf("----------------------------------\n\n");
    printf("> 1. User Management Panel \n");
    printf("> 2. Book Management Panel \n\n");
    printf("> Enter the number & hit ENTER: ");
    int number;
    scanf("%d", &number);
    getchar();  // Clear the newline character left in the input buffer
    switch (number) {
        case 1:
            userPanel();
            break;
        case 2:
            bookPanel();
            break;
        default:
            printf("\n>>> Invalid Input! Redirecting to Main Menu... <<<\n");
            usleep(2000000);
            menu();
    }
}

void userPanel() {
    system("clear || cls");

    int number;

    printf("-----------------------------------------------\n");
    printf(">>> Library Management System - User Panel <<< \n");
    printf("-----------------------------------------------\n\n");
    printf("> 1. Add User \n");
    printf("> 2. Search User \n");
    printf("> 3. Delete User \n");
    printf("> 4. List Users \n");
    printf("> 5. Open Main Menu \n");
    printf("> 6. Close the Program... \n\n");

    printf("> Enter the number & hit ENTER: ");
    scanf("%d", &number);
    getchar();  // Clear the newline character left in the input buffer

    switch (number) {
        case 1:
            addUser();
            break;
        case 2:
            searchUser(0);
            break;
        case 3:
            deleteUser();
            break;
        case 4:
            userList();
            break;
        case 5:
            menu();
            break;
        case 6:
            endScreen();
            break;
        default:
            printf("\n>>> Invalid Input! Redirecting to User Panel... <<<\n");
            usleep(2000000);
            userPanel();
    }
}

void bookPanel() {
    system("clear || cls");

    int number;

    printf("-----------------------------------------------\n");
    printf(">>> Library Management System - Book Panel <<< \n");
    printf("-----------------------------------------------\n\n");
    printf("> 1. Add Book \n");
    printf("> 2. List Book \n");
    printf("> 3. Rent Book \n");
    printf("> 4. Search Book \n");
    printf("> 5. Delete Book \n");
    printf("> 6. Open Main Menu \n");
    printf("> 7. Close the Program... \n");

    printf("\n> Enter the number & hit ENTER: ");
    scanf("%d", &number);
    getchar();  // Clear the newline character left in the input buffer

    switch (number) {
        case 1:
            addBook();
            break;
        case 2:
            listBook();
            break;
        case 3:
            rentBook();
            break;
        case 4:
            searchBook(0);
            break;
        case 5:
            deleteBook();
            break;
        case 6:
            menu();
            break;
        case 7:
            endScreen();
            break;
        default:
            printf("\n>>> Invalid Input! Redirecting to Book Panel... <<<\n");
            usleep(2000000);
            bookPanel();
    }
}

void addUser() {
    while (1) {
        system("clear || cls");

        char fname[255], lname[255];
        char gender;
        double sid, phone;

        FILE *pF = fopen("user_Records.txt", "a+");

        if (pF != NULL) {
            printf("Enter the First Name: ");
            scanf("%s", fname);

            printf("Enter the Last Name: ");
            scanf("%s", lname);

            printf("Enter Gender [M/F]: ");
            scanf(" %c", &gender);

            printf("Enter Student ID: ");
            scanf("%lf", &sid);

            printf("Enter Phone Number: ");
            scanf("%lf", &phone);

            fprintf(pF, "%s %s %c %.0lf %.0lf\n", fname, lname, gender, sid, phone);
            printf("\n>>> User Record Added Successfully <<< \n");

            fclose(pF);
        } else {
            printf("Unable to open/locate the file.\n");
        }

        getchar();  // Clear the newline character left in the input buffer

        char input;
        printf("\nDo you want to enter more records [y/N]: ");
        scanf(" %c", &input);

        if (input == 'n' || input == 'N') {
            printf("\nRedirecting to User Panel.\n");
            usleep(2000000);
            userPanel();
            break;
        } else if (input != 'y' && input != 'Y') {
            printf("\nInvalid input. Redirecting to User Panel.\n");
            usleep(2000000);
            userPanel();
            break;
        }
    }
}

void searchUser(int x) {
    system("clear || cls");

    FILE *pF = fopen("user_Records.txt", "r");

    if (pF == NULL) {
        printf("Unable to open/locate the file.\n");
        return;
    }

    double sid;
    printf("Enter the Student ID to search: ");
    scanf("%lf", &sid);

    char fname[255], lname[255], gender[5];
    double recordSid, phone;
    int found = 0;

    printf("-------------------------------\n");
    printf(">>> User Record Search Result <<< \n");
    printf("-------------------------------\n\n");

    while (fscanf(pF, "%s %s %s %lf %lf", fname, lname, gender, &recordSid, &phone) != EOF) {
        if (recordSid == sid) {
            printf("-------------------------------\n");
            printf("> Full Name: %s %s \n", fname, lname);
            printf("> Gender: %s \n", gender);
            printf("> Student-ID: %.0lf \n", recordSid);
            printf("> Phone No.: %.0lf \n", phone);
            printf("-------------------------------\n\n\n");
            found = 1;
            break; // Stop searching after finding the first match
        }
    }

    fclose(pF);

    if (!found) {
        printf("-------------------------------------\n");
        printf("No user record found with Student ID: %.0lf\n", sid);
        printf("--------------------------------------\n\n");
    }

    printf("Press any key to get back to User Panel.\n");
    getchar();
    getchar();
    userPanel();
}

void deleteUser() {
    system("clear || cls");

    double sid;
    printf("Enter the Student ID of the user to delete: ");
    scanf("%lf", &sid);

    char fname[255], lname[255], gender[5];
    double recordSid, phone;
    int found = 0;

    FILE *pF = fopen("user_Records.txt", "r");
    FILE *pT = fopen("temporary.txt", "a");

    if (pF == NULL || pT == NULL) {
        printf("Unable to open/locate the file.\n");
        return;
    }

    while (fscanf(pF, "%s %s %s %lf %lf", fname, lname, gender, &recordSid, &phone) != EOF) {
        if (recordSid == sid) {
            printf("\n---------------------------------------------\n");
            printf(">>> User Record Deleted <<<\n");
            printf("-----------------------------------------------\n\n");
            printf("> Full Name: %s %s \n", fname, lname);
            printf("> Gender: %s \n", gender);
            printf("> Student-ID: %.0lf \n", recordSid);
            printf("> Phone No.: %.0lf \n", phone);
            printf("-----------------------------------------------\n\n");
            found = 1;
        } else {
            fprintf(pT, "%s %s %s %.0lf %.0lf\n", fname, lname, gender, recordSid, phone);
        }
    }

    fclose(pF);
    fclose(pT);

    if (!found) {
        printf("\n\n-------------------------------\n");
        printf(">>> Record Not Found <<<\n");
        printf("-------------------------------\n\n");
    }

    remove("user_Records.txt");
    rename("temporary.txt", "user_Records.txt");

    printf("Press any key to get back to User Panel.\n");
    getchar();
    getchar();
    userPanel();
}
void userList() {
    system("clear || cls");

    FILE *pF = fopen("user_Records.txt", "r");

    if (pF == NULL) {
        printf("Unable to open/locate the file.\n");
        return;
    }

    char fname[255], lname[255], gender[5];
    double sid, phone;

    printf("-------------------------------\n");
    printf(">>> List of Users Record <<< \n");
    printf("-------------------------------\n\n");

    while (fscanf(pF, "%s %s %s %lf %lf", fname, lname, gender, &sid, &phone) != EOF) {
        printf("-------------------------------\n");
        printf("> Full Name: %s %s \n", fname, lname);
        printf("> Gender: %s \n", gender);
        printf("> Student-ID: %.0lf \n", sid);
        printf("> Phone No.: %.0lf \n", phone);
        printf("-------------------------------\n\n\n");
    }

    fclose(pF);

    printf("Press any key to get back to User Panel.\n");
    getchar();
    getchar();
    userPanel();
}
void addBook() {
  while (1) {
    system("clear || cls");

    char name[255], author[255];
    double isbn;
    int quantity;

    FILE *pF = fopen("book_Records.txt", "a+");

    if (pF != NULL) {
      printf("Enter the Book Name: ");
      fgets(name, sizeof(name), stdin);
      name[strcspn(name, "\n")] = 0; // Remove the trailing newline character

      printf("Enter the Author's Name: ");
      fgets(author, sizeof(author), stdin);
      author[strcspn(author, "\n")] = 0; // Remove the trailing newline character

      printf("Enter the ISBN Number: ");
      scanf("%lf", &isbn);
      getchar(); // Consume the newline character left in the input buffer

      printf("Enter the Quantity: ");
      scanf("%d", &quantity);
      getchar(); // Consume the newline character left in the input buffer

      fprintf(pF, "%s\n%s\n%.0lf %d\n", name, author, isbn, quantity);
      printf("\n>>> Book Record Added Successfully <<< \n");

      fclose(pF);
    } else {
      printf("Unable to open/locate the file.\n");
    }

    getchar(); // Consume newline character left in the input buffer
    printf("\nDo you want to add another record [y/N]: ");
    char input = getchar();
    if (input == 'n' || input == 'N') {
      printf("\nRedirecting to Book Panel.\n");
      usleep(2000000);
      bookPanel();
      break;
    } else if (input != 'y' && input != 'Y') {
      printf("\nInvalid input. Redirecting to Book Panel.\n");
      usleep(2000000);
      bookPanel();
      break;
    }
  }
}
void listBook() {
    system("clear || cls");

    FILE *pF = fopen("book_Records.txt", "r");

    if (pF == NULL) {
        printf("Unable to open/locate the file.\n");
        return;
    }

    char name[255], author[255];
    double isbn;
    int quantity;

    printf("-------------------------------\n");
    printf(">>> List of Books Record <<< \n");
    printf("-------------------------------\n\n");

    while (fgets(name, sizeof(name), pF) != NULL) {
        name[strcspn(name, "\n")] = 0; // Remove trailing newline
        fgets(author, sizeof(author), pF);
        author[strcspn(author, "\n")] = 0; // Remove trailing newline
        fscanf(pF, "%lf %d\n", &isbn, &quantity); // Read the remaining line for isbn and quantity

        printf("-------------------------------\n");
        printf("> Book Name: %s \n", name);
        printf("> Author's Name: %s \n", author);
        printf("> ISBN Number: %.0lf \n", isbn);
        printf("> Quantity: %d \n", quantity);
        printf("-------------------------------\n\n");
    }

    fclose(pF);

    printf("Press any key to get back to Book Panel.\n");
    getchar();
    getchar();
    bookPanel();
}


void searchBook(int x) {
    system("clear || cls");

    FILE *pF = fopen("book_Records.txt", "r");

    if (pF == NULL) {
        printf("Unable to open/locate the file.\n");
        return;
    }

    double searchIsbn;
    printf("Enter the ISBN Number to search: ");
    scanf("%lf", &searchIsbn);

    char name[255], author[255];
    double isbn;
    int quantity;
    int found = 0;

    printf("-------------------------------\n");
    printf(">>> Book Record Search Result <<< \n");
    printf("-------------------------------\n\n");

    while (fgets(name, sizeof(name), pF) != NULL) {
        name[strcspn(name, "\n")] = 0; // Remove trailing newline
        fgets(author, sizeof(author), pF);
        author[strcspn(author, "\n")] = 0; // Remove trailing newline
        fscanf(pF, "%lf %d\n", &isbn, &quantity); // Read the remaining line for isbn and quantity

        if (isbn == searchIsbn) {
            printf("-------------------------------\n");
            printf("> Book Name: %s \n", name);
            printf("> Author: %s \n", author);
            printf("> ISBN Number: %.0lf \n", isbn);
            printf("> Quantity: %d \n", quantity);
            printf("-------------------------------\n\n\n");
            found = 1;
            break; // Stop searching after finding the first match
        }
    }

    fclose(pF);

    if (!found) {
        printf("-------------------------------------\n");
        printf("No book record found with ISBN: %.0lf\n", searchIsbn);
        printf("--------------------------------------\n\n");
    }

    printf("Press any key to get back to Book Panel.\n");
    getchar();
    getchar();
    bookPanel();
}

void rentBook() {
    system("clear || cls");

    double searchIsbn;
    printf("Enter the ISBN Number to rent: ");
    scanf("%lf", &searchIsbn);

    char name[255], author[255];
    double isbn;
    int quantity;
    int found = 0;

    FILE *pF = fopen("book_Records.txt", "r");
    FILE *pT = fopen("temporary.txt", "a");

    if (pF == NULL || pT == NULL) {
        printf("Unable to open/locate the file.\n");
        return;
    }

    while (fgets(name, sizeof(name), pF) != NULL) {
        name[strcspn(name, "\n")] = 0; // Remove trailing newline
        fgets(author, sizeof(author), pF);
        author[strcspn(author, "\n")] = 0; // Remove trailing newline
        fscanf(pF, "%lf %d\n", &isbn, &quantity); // Read the remaining line for isbn and quantity

        if (isbn == searchIsbn && quantity > 0) {
            quantity--;
            printf("\n---------------------------------------------\n");
            printf(">>> Book Rented Successfully <<<\n");
            printf("-----------------------------------------------\n\n");
            printf("> Book Name: %s \n", name);
            printf("> Author: %s \n", author);
            printf("> ISBN Number: %.0lf \n", isbn);
            printf("> Remaining Copies: %d \n", quantity);
            printf("-----------------------------------------------\n\n");
            found = 1;
        }
        fprintf(pT, "%s\n%s\n%.0lf %d\n", name, author, isbn, quantity);
    }

    fclose(pF);
    fclose(pT);

    if (!found) {
        printf("\n\n-------------------------------\n");
        printf(">>> Book Not Found or Unavailable <<<\n");
        printf("-------------------------------\n\n");
    }

    remove("book_Records.txt");
    rename("temporary.txt", "book_Records.txt");

    printf("Press any key to get back to Book Panel.\n");
    getchar();
    getchar();
    bookPanel();
}

void deleteBook() {
    system("clear || cls");

    double searchIsbn;
    printf("Enter the ISBN Number of the book to delete: ");
    scanf("%lf", &searchIsbn);

    char name[255], author[255];
    double isbn;
    int quantity;
    int found = 0;

    FILE *pF = fopen("book_Records.txt", "r");
    FILE *pT = fopen("temporary.txt", "a");

    if (pF == NULL || pT == NULL) {
        printf("Unable to open/locate the file.\n");
        return;
    }

    while (fgets(name, sizeof(name), pF) != NULL) {
        name[strcspn(name, "\n")] = 0; // Remove trailing newline
        fgets(author, sizeof(author), pF);
        author[strcspn(author, "\n")] = 0; // Remove trailing newline
        fscanf(pF, "%lf %d\n", &isbn, &quantity); // Read the remaining line for isbn and quantity

        if (isbn == searchIsbn) {
            printf("\n---------------------------------------------\n");
            printf(">>> Book Record Deleted <<<\n");
            printf("-----------------------------------------------\n\n");
            printf("> Book Name: %s \n", name);
            printf("> Author: %s \n", author);
            printf("> ISBN Number: %.0lf \n", isbn);
            printf("> Quantity: %d \n", quantity);
            printf("-----------------------------------------------\n\n");
            found = 1;
        } else {
            fprintf(pT, "%s\n%s\n%.0lf %d\n", name, author, isbn, quantity);
        }
    }

    fclose(pF);
    fclose(pT);

    if (!found) {
        printf("\n\n-------------------------------\n");
        printf(">>> Book Record Not Found <<<\n");
        printf("-------------------------------\n\n");
    }

    remove("book_Records.txt");
    rename("temporary.txt", "book_Records.txt");

    printf("Press any key to get back to Book Panel.\n");
    getchar();
    getchar();
    bookPanel();
}


void endScreen() {
    printf("\n------------------------------------\n");
    printf(">>> Program Closed Successfully <<<\n");
    printf("------------------------------------\n");
    exit(0);
}
